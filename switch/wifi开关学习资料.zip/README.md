1. 用`ESP8266Flasher`烧写`nodemcu.bin`。需要在拉低GPIO0时按一下RST。
2. 用`LuaLoader`写入`init.lua`脚本。



twd2